import network
import socket
import time
import random

port=10075
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect('GalaxyM21C6C9', 'dhdx4435')
while(wlan.isconnected() == False):
  time.sleep(1)
ip = wlan.ifconfig()[0] # ip is of nodemcu when it connect to internet
print("Nodemcu IP Address: ", ip)

s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind((ip,port))

client_ip_addr = '192.168.103.178'  # 192.168.103.178 is ip address of Laptop where udp client will run

while True:
#   print("####### Server is listening #######")
#   data,addr=s.recvfrom(1024)
#   print('Received:',data.decode('utf-8'),'from',addr)
#   if(data.decode('utf-8') == "stop"):
#       s.close()
#       break
    
  for i in range(5):
#     client_data = (random.getrandbits(8)).to_bytes(2, 'big')
    client_data = str(random.getrandbits(8))
    print("Sending temperature: ", client_data)
    s.sendto(client_data, (client_ip_addr, port))
    time.sleep(0.5)   
  
  break
print("Connection Closed")
s.close()

  
  
