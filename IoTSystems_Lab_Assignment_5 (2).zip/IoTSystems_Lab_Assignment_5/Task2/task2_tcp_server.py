import random
import socket
import time

import network

import esp
esp.osdebug(None)

import gc
gc.collect()

ssid = 'GalaxyM21C6C9'
password = 'dhdx4435'

station = network.WLAN(network.STA_IF)

station.active(True)
station.connect(ssid, password)
while station.isconnected() == False:
  pass
print('Connection successful')
print(station.ifconfig())   # This server ip is need to put in client script to connect with server
# server_ip = station.ifconfig()
# server_ip = server_ip[0]

port = 10025
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# s.bind((server_ip, 10025))  # When we do this means we are connecting to particular Ip
# Next bind to the port
# we have not typed any ip in the ip field
# instead we have inputted an empty string
# this makes the server listen to requests
# coming from other computers on the network
s.bind(('', port)) 
s.listen(10)

temperature = []
for i in range(256):
      temperature.append(random.getrandbits(8))

pos = random.getrandbits(8)

while True:
  # Establish connection with client.
  c, addr = s.accept()    
  print ('Got connection from', addr )
 
  # send a thank you message to the client. encoding to send byte type.
  print("Sending temperature: ", temperature[pos])
  # c.sendall(bytes( temperature,"utf-8"))
  c.send(str(temperature[pos]).encode())
 
  # Close the connection with the client
  c.close()
   
  # Breaking once connection closed
  break

# Close the socket    
s.close()
