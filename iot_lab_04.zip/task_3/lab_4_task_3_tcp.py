import random
import socket
import time
import json

from machine import Pin
import network

import esp
esp.osdebug(None)

import gc
gc.collect()

ssid = 'vivo 1803'
password = '8eb2233ab'

station = network.WLAN(network.STA_IF)

station.active(True)
station.connect(ssid, password)

while station.isconnected() == False:
  pass

print('Connection successful')
print(station.ifconfig())
server_ip = station.ifconfig()

# temperature = random.randint(0, 45)
# fan_state = random.randint(0, 1)
# humidity = random.randint(0, 10)

def data_generator():
    temperature = str(random.getrandbits(8))
    fan_state = str(random.getrandbits(1))
    humidity = str(random.getrandbits(4))

    data = {
        "temperature": temperature,
        "fan_state": fan_state,
        "humidity": humidity
    }
    print("Data need to be send:", str(data))
    return data

 
server_ip = server_ip[0]
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((server_ip, 10025))
s.listen(2)
conn,addr = s.accept()

while True:
    for i in range(10):
        conn.sendall(bytes(json.dumps(data_generator()),"utf-8"))
        time.sleep(1)   #This is required for TCP value get transfered successfully
    conn.close()
    break
# Close the socket    
s.close()
