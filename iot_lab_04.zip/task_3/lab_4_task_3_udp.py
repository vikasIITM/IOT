import random
import socket
import time
import json

from machine import Pin
import network

import esp
esp.osdebug(None)

import gc
gc.collect()

port=10071
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect('vivo 1803', '8eb2233ab')
while(wlan.isconnected() == False):
  time.sleep(1)
print('Connection successful')
ip = wlan.ifconfig()[0]
print(ip)

s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind((ip,port))

# temperature = random.randint(0, 45)
# fan_state = random.randint(0, 1)
# humidity = random.randint(0, 10)

def data_generator():
    temperature = str(random.getrandbits(8))
    fan_state = str(random.getrandbits(1))
    humidity = str(random.getrandbits(4))

    data = {
        "temperature": temperature,
        "fan_state": fan_state,
        "humidity": humidity
    }
    print("Data need to be send:", str(data))
    json_data = json.dumps(data)
    return json_data

 
while True:
    for i in range(10):
        s.sendto(bytes(data_generator(),"utf-8"), ('192.168.43.27', port))  # 192.168.103.178 is ip address of Laptop where Node-red is running
        time.sleep(0.5)   #This is required for UDP value get transfered successfully 
    break
print("Connection Closed")
s.close()
